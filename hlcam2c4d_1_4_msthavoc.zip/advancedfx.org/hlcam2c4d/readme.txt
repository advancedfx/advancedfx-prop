*******************************************************************************
                             HLAE Cam 2 Cinema4D 
*******************************************************************************

-------------------------------------------------------------------------------
                            General Information
-------------------------------------------------------------------------------
Type.................: Plugin
Platform.............: Windows/MAC 
Coder................: msthavoc (just community relations) 
Code-Language........: COFFEE (SDK 9.5/11 used)
Version..............: 1.4
Language.............: English
Team.................: HLAE Developing Team
C4D-Versions.........: Created with R12  
-------------------------------------------------------------------------------

===============================================================================

-------------------------------------------------------------------------------
                              Disclaimer
-------------------------------------------------------------------------------
 Altered versions must be cleary marked as such and must not be misrepresented
 as being the original software.
 
 This software is for your enjoyment and you are using it at your own risk.
-------------------------------------------------------------------------------

===============================================================================

-------------------------------------------------------------------------------
                             Installation
-------------------------------------------------------------------------------
 just unpack to you plugin path(Maxon\Cinema 4D\plugins)                         
 
 After running CINEMA 4D, you should see an entry in your console
				"Loaded HLAE Cam 2 Cinema4D"

 
-------------------------------------------------------------------------------

===============================================================================

-------------------------------------------------------------------------------
                              Notes
-------------------------------------------------------------------------------
 The Plugin contains a Modal dialogs as Interface, this means while your 
 plugin is open, it takes full control of the application, requiring the user 
 to dismiss it before continuing working.

 90� fix means, the whole campath will be rotate 90 �, so it fits to some map exporters, who rotates the map
 e.g. BSP viewer

 The check on change projects, allows the plugin to change the MAX Time and
 frames/second of your Project. You get the settings from your captured scene

 Before you import the HLAE *.bvh, you should enter the fov, used in the 
 Capturing. Don't afraid, you also can change the fov-value after Import, in your 
 Camera Attributes.
 
-------------------------------------------------------------------------------

===============================================================================

Sincerly,
your Half-Life Advanced Effects team.
                                        