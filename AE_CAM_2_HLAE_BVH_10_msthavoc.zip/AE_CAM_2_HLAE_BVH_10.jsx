﻿//#test version ae export
//author: msthavoc
var myComp = app.project.activeItem;
var cam = null;
var x = 0;
if (myComp != null)
{
	var i = 1;
	for(var i = 1; i<(myComp.numLayers+1);i++)
	{
		if (myComp.layer(i).selected == true){
			if(myComp.layer(i).depthOfField != undefined)
				{
					cam = myComp.layer(i);
					x = i;
				}
				else
		}
	}	
}
else
{
	alert("no composition selected");
}




//String.fromCharCode(10) == LF 
//"\n" = CR LF 







if (cam != null)
{
	var exit=confirm("Camera-Layer found:"+myComp.layer(x).name+"\nparent Objects:\n--->"+myComp.layer(x).parent.name + "\n------>"+myComp.layer(x).parent.parent.name);	
	if (exit){
			var frames = myComp.frameRate*myComp.duration;
			var frametime = 1/myComp.frameRate;
			var camera = myComp.layer(x);
			var null_XZ = camera.parent;
			var null_Y = null_XZ.parent;
			var bvh_content = "";
			var count=6;
			//var count2=6;
			//adding header
			bvh_content += "HIERARCHY\nROOT MdtCam\n{\n	OFFSET 0.00 0.00 0.00\n	CHANNELS 6 Xposition Yposition Zposition Zrotation Xrotation Yrotation\n	End Site\n	{\n		OFFSET 0.00 0.00 -1.00\n	}\n}\nMOTION\n";
			
			
			//adding FRAMES: 
			bvh_content += "Frames: ";
			bvh_content += frames;
			bvh_content += "\n";
			//adding FRAMETIME
			bvh_content += "Frame Time: ";
			bvh_content += frametime;
			bvh_content += "\n";
			
			//File.saveDialog
			for (var j = 0; j < (frames-1); j++){
				/*
				bvh_content += (Math.round((null_Y.transform.position.valueAtTime(j/myComp.frameRate,true)[0])*count)/count).toFixed(count2);   //X
				bvh_content += "  ";
				bvh_content += (Math.round((null_Y.transform.position.valueAtTime(j/myComp.frameRate,true)[1]*(-1))*count)/count).toFixed(count2); //Y*-1
				bvh_content += "  ";
				bvh_content += (Math.round((null_Y.transform.position.valueAtTime(j/myComp.frameRate,true)[2]*(-1))*count)/count).toFixed(count2);   //Z*-1
				bvh_content += "  ";
				//rotation
				bvh_content += (Math.round((null_XZ.transform.zRotation.valueAtTime(j/myComp.frameRate,true)*(-1))*count)/count).toFixed(count2);   //Z*-1
				bvh_content += "  ";
				bvh_content += (Math.round((null_XZ.transform.xRotation.valueAtTime(j/myComp.frameRate,true))*count)/count).toFixed(count2);   //X
				bvh_content += "  ";
				bvh_content += (Math.round((null_Y.transform.yRotation.valueAtTime(j/myComp.frameRate,true)*(-1))*count)/count).toFixed(count2);   //Y*-1
				bvh_content += "\n";	
				*/
	
	
	
				
				//one line in bvh
				//position	
				bvh_content += (null_Y.transform.position.valueAtTime(j/myComp.frameRate,true)[0]).toFixed(count);   //X
				bvh_content += " ";
				bvh_content += (null_Y.transform.position.valueAtTime(j/myComp.frameRate,true)[1]*(-1)).toFixed(count);   //Y*-1
				bvh_content += " ";
				bvh_content += (null_Y.transform.position.valueAtTime(j/myComp.frameRate,true)[2]*(-1)).toFixed(count);   //Z*-1
				bvh_content += " ";
				//rotation
				bvh_content += (null_XZ.transform.zRotation.valueAtTime(j/myComp.frameRate,true)*(-1)).toFixed(count);   //Z*-1
				bvh_content += " ";
				bvh_content += (null_XZ.transform.xRotation.valueAtTime(j/myComp.frameRate,true)).toFixed(count);   //X
				bvh_content += " ";
				bvh_content += (null_Y.transform.yRotation.valueAtTime(j/myComp.frameRate,true)*(-1)).toFixed(count);   //Y*-1
				bvh_content += "\n";
				
			}
		
	/*
		
				
		
	*/
			
			
			
			var file = File.saveDialog("Save your cammotion file", "bvh");
            file.encoding ="BINARY";
			if (file.open("e", "TEXT", "msthavoc"))
			{                   
                   
				file.write(bvh_content);
				file.close();
			}
			
			//hlaefile.open("e","BVH","msthavoc");
			
			//hlaefile.encode("adsdgsgsg");
			
	
			
			//hlaefile.close();			
			
			
		
		
			//alert(bvh_content);
			
			//alert(frames + "\n" + frametime );
			
			//myPosition = myComp.layer(x).parent.parent.transform.position;
			//alert(myPosition.valueAtTime(0,true));

			
		

		}
	
}
else
{
	alert("Camera-Layer not found!\nPlease go into your Composition and select the HLAE Camera.");	
}



//var myToolsPanel = createUI(this);
//myToolsPanel.show();
