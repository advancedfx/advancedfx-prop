HLAE Camera Motion Export for Blender

Installation:
  Copy hlae_camexport.py into your Blender's script directory.

For more information visit
  http://advancedfx.org/
