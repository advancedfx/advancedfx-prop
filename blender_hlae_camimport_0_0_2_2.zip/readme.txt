HLAE Camera Motion Import for Blender

Installation:
  Copy hlae_camimport.py into your Blender's script directory.

For more information visit
  http://advancedfx.org/
